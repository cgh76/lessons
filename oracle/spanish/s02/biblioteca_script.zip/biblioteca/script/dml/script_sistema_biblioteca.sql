-- script sistema prestamo biblioteca
declare
    v_opcion varchar2(10):= '';

	v_id_usuario NUMBER;
    v_nombre     VARCHAR2(100);
    v_email      VARCHAR2(100);
    v_telefono   VARCHAR2(15);

	procedure p ( valor in varchar2 ) is
	begin
		dbms_output.put_line( valor );
	end;
	
begin

		p('Sistema Prestamo Libros');
		p('1.- registrar autor');
		p('2.- registrar libro');	
		p('3.- registrar usuario');
		p('4.- registrar prestamo');
		p('5.- registrar devolucion');
		p('9.- salir');
		p('ingrese una opcion');

		v_opcion := :p_opcion;	

		p('opcion seleccionada: '||v_opcion);
		case v_opcion
			when '1' then
				p('opcion seleccionada: '||v_opcion);
			when '2' then
				p('opcion = '||v_opcion);
				DECLARE 
					v_id_libro  NUMBER := 108;
					v_titulo    VARCHAR2(100) := 'El otoño del patriarca';
					v_id_autor  NUMBER := 1;
					v_isbn      VARCHAR2(13) := '9780307474759';
					v_año       NUMBER := 1975;
					v_cantidad  NUMBER := 4;
				BEGIN
					v_id_libro := :p_id_libro;
					v_titulo := :p_titulo;
					v_id_autor := :p_id_autor;
					v_isbn := :p_isbn;
					v_año := :p_año;
					v_cantidad := :p_cantidad;

					registrar_libro(   
						V_id_libro,
						V_titulo,
						V_id_autor,
						V_isbn,
						V_año,
						V_cantidad
					);
				END;
			when '3' then
				p('opcion = '||v_opcion);
				DECLARE 
					v_id_usuario NUMBER := 7;
					v_nombre     VARCHAR2(100) := 'Carolina';
					v_email      VARCHAR2(100) := 'caro@example.com';
					v_telefono   VARCHAR2(15) := '555-1235';  
				BEGIN
					v_id_usuario := :p_id_usuario;
					v_nombre := :p_nombre;
					v_email := :p_email;
					v_telefono := :p_telefono;
					registrar_usuario(
						v_id_usuario,
						v_nombre,
						v_email,
						v_telefono
					);
				END;
	/*

			/*when '8' then
				begin

					v_id_usuario := :p_id_usuario;
					v_nombre := :p_nombre;
					v_email := :p_email;
					v_telefono := :p_telefono;

					registrar_usuario (
						v_id_usuario,
						v_nombre,
						v_email,
						v_telefono
					);
				end;	
				*/
			else 
				p('opción invalida');
		end case;
		/*
		if (v_opcion = '1') then
			p('opcion = '||v_opcion);
		else if (v_opcion = '2') then
			p('opcion = '||v_opcion);
		else if (v_opcion = '8') then
			begin
			EXEC sp_crear_usuario (
				:p_codigo,
				:p_nombre,
				:p_rol,
				:p_comentarios
			);
			end;	
		else 
			p('opción invalida');
		end if;
		*/
end;