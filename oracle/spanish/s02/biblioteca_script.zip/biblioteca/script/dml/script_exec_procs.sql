
-- EJECUTA Procedimiento para registrar un nuevo usuario
-- select * from USUARIOS;
DECLARE 
    v_id_usuario NUMBER := 6;
    v_nombre     VARCHAR2(100) := 'Laura Fernández';
    v_email      VARCHAR2(100) := 'laura.fernandez@example.com';
    v_telefono   VARCHAR2(15) := '555-1234';  
BEGIN
    registrar_usuario(
        v_id_usuario,
        v_nombre,
        v_email,
        v_telefono
    );
END;
/

-- version construye varuiables con bind variables
-- select * from USUARIOS;
DECLARE 
    v_id_usuario NUMBER := 7;
    v_nombre     VARCHAR2(100) := 'Carolina';
    v_email      VARCHAR2(100) := 'caro@example.com';
    v_telefono VARCHAR2(15) := '555-1235';  
BEGIN
    --
    v_id_usuario := :p_id_usuario;
    v_nombre := :p_nombre;
    v_email := :p_email;
    v_telefono := :p_telefono;
    registrar_usuario(
        v_id_usuario,
        v_nombre,
        v_email,
        v_telefono
    );
END;
/

-- Procedimiento para registrar un nuevo libro
-- select * from LIBROS;
DECLARE 
    v_id_libro  NUMBER := 107;
    v_titulo    VARCHAR2(100) := 'El otoño del patriarca';
    v_id_autor  NUMBER := 1;
    v_isbn      VARCHAR2(13) := '9780307474759';
    v_año       NUMBER := 1975;
    v_cantidad  NUMBER := 4;
BEGIN
    registrar_libro(   
        V_id_libro,
        V_titulo,
        V_id_autor,
        V_isbn,
        V_año,
        V_cantidad
    );
END;
/

-- Procedimiento para registrar un nuevo libro
-- select * from LIBROS;
DECLARE 
    v_id_libro  NUMBER := 108;
    v_titulo    VARCHAR2(100) := 'El otoño del patriarca';
    v_id_autor  NUMBER := 1;
    v_isbn      VARCHAR2(13) := '9780307474759';
    v_año       NUMBER := 1975;
    v_cantidad  NUMBER := 4;
BEGIN
    v_id_libro := :p_id_libro;
    v_titulo := :p_titulo;
    v_id_autor := :p_id_autor;
    v_isbn := :p_isbn;
    v_año := :p_año;
    v_cantidad := :p_cantidad;

    registrar_libro(   
        V_id_libro,
        V_titulo,
        V_id_autor,
        V_isbn,
        V_año,
        V_cantidad
    );
END;
/



-- Procedimiento para registrar un nuevo préstamo
-- select * from PRESTAMOS;
declare
    v_id_prestamo NUMBER;  
    v_id_usuario NUMBER;
    v_id_libro NUMBER;
begin
    v_id_prestamo := :p_id_prestamo;
    v_id_usuario := :p_id_usuario;
    v_id_libro := :p_id_libro;
    registrar_prestamo(
        p_id_prestamo => v_id_prestamo,
        p_id_usuario => v_id_usuario,
        p_id_libro => v_id_libro
    );
    dbms_output.put_line('Préstamo registrado exitosamente');
end; 

-- Procedimiento para registrar devolución
DECLARE
    v_id_prestamo NUMBER := :p_id_prestamo;
BEGIN
    registrar_devolucion(v_id_prestamo);        
END;    

CREATE OR REPLACE PROCEDURE registrar_devolucion(
    p_id_prestamo IN NUMBER
) AS
    v_id_libro NUMBER;
BEGIN
    UPDATE PRESTAMO SET estado = 'DEVUELTO', fecha_devolucion = SYSDATE
    WHERE id_prestamo = p_id_prestamo
    RETURNING id_libro INTO v_id_libro;
    
    UPDATE LIBRO SET cantidad_disponible = cantidad_disponible + 1
    WHERE id_libro = v_id_libro;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Devolución registrada exitosamente');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END registrar_devolucion;
/



-- Función para obtener el total de préstamos activos de un usuario
DECLARE
    v_id_usuario NUMBER := :p_id_usuario;
    v_total_prestamos NUMBER;
BEGIN
    v_total_prestamos := contar_prestamos_activos(v_id_usuario);
    DBMS_OUTPUT.PUT_LINE('Total de préstamos activos: ' || v_total_prestamos);
END;
/


-- Procedimiento para generar reporte de préstamos vencidos
BEGIN
    reporte_prestamos_vencidos;
END;




/* 
ejemplo de como ejecutar un procedimiento con parametros nombrados
*/

BEGIN
    nombre_del_procedimiento(
        parametro2 => valor2,
        parametro1 => valor1
    );
END;
/
