
--
select * from AUTOR;

select * from LIBRO;

select * from USUARIO;

select * from PRESTAMO;


-- Consulta 1: Listar todos los libros con información del autor
SELECT l.id_libro, l.titulo, a.nombre, a.apellido, l.año_publicacion
FROM   LIBRO l
JOIN   AUTOR a ON l.id_autor = a.id_autor
ORDER BY l.titulo;

-- Consulta 2: Buscar libros disponibles
SELECT id_libro, titulo, cantidad_disponible
FROM LIBROS
WHERE cantidad_disponible > 0
ORDER BY titulo;

-- Consulta 3: Listar usuarios registrados en el último mes
SELECT id_usuario, nombre, email, fecha_registro
FROM USUARIOS
WHERE fecha_registro >= ADD_MONTHS(SYSDATE, -1)
ORDER BY fecha_registro DESC;


/*
tablas de sistema de oracle
*/

select * from all_tables;

select * from all_objects;

select * from all_source;

select * from user_source where object_name = 'user_source';