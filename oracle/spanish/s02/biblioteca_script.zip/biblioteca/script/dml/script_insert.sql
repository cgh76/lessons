
--Insertar Autores
INSERT INTO AUTOR (id_autor, nombre, apellido, fecha_nacimiento) VALUES (1, 'Gabriel', 'García Márquez', TO_DATE('1927-03-06', 'YYYY-MM-DD'));
INSERT INTO AUTOR (id_autor, nombre, apellido, fecha_nacimiento) VALUES (2, 'Isabel', 'Allende', TO_DATE('1942-08-02', 'YYYY-MM-DD'));
INSERT INTO AUTOR (id_autor, nombre, apellido, fecha_nacimiento) VALUES (3, 'Jorge', 'Luis Borges', TO_DATE('1899-08-24', 'YYYY-MM-DD'));
INSERT INTO AUTOR (id_autor, nombre, apellido, fecha_nacimiento) VALUES (4, 'Julio', 'Cortázar', TO_DATE('1914-08-26', 'YYYY-MM-DD'));
INSERT INTO AUTOR (id_autor, nombre, apellido, fecha_nacimiento) VALUES (5, 'Mario', 'Vargas Llosa', TO_DATE('1936-03-28', 'YYYY-MM-DD'));


INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible) VALUES (101, 'Cien años de soledad', 1, '9780307474728', 1967, 5);
INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible) VALUES (102, 'El amor en los tiempos del cólera', 1, '9780307387264', 1985, 3);
INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible) VALUES (103, 'La casa de los espíritus', 2, '9780307474773', 1922, 4);
INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible) VALUES (104, 'Ficciones', 3, '9780307950925', 1944, 2);
INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible) VALUES (105, 'Rayuela', 4, '9780307474735', 1963, 3);
INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible) VALUES (106, 'La ciudad y los perros', 5, '9780307474742', 1963, 2);

INSERT INTO USUARIO (id_usuario, nombre, email, telefono, fecha_registro) VALUES (1, 'Juan Pérez', 'juan.perez@email.com', '+56912345678', TO_DATE('2025-01-15', 'YYYY-MM-DD'));
INSERT INTO USUARIO (id_usuario, nombre, email, telefono, fecha_registro) VALUES (2, 'María José López', 'maria.lopez@email.com', '+56987654321', TO_DATE('2025-02-20', 'YYYY-MM-DD'));
INSERT INTO USUARIO (id_usuario, nombre, email, telefono, fecha_registro) VALUES (3, 'Carlos Mendoza', 'carlos.m@email.com', '+56955554444', TO_DATE('2025-03-01', 'YYYY-MM-DD'));
INSERT INTO USUARIO (id_usuario, nombre, email, telefono, fecha_registro) VALUES (4, 'Ana Silva', 'ana.silva@email.com', '+56933332222', TO_DATE('2025-03-10', 'YYYY-MM-DD'));
INSERT INTO USUARIO (id_usuario, nombre, email, telefono, fecha_registro) VALUES (5, 'Diego Torres', 'diego.t@email.com', NULL, TO_DATE('2025-03-15', 'YYYY-MM-DD'));


-- Préstamo activo (sin fecha de devolución)
INSERT INTO PRESTAMO (id_prestamo, id_usuario, id_libro, fecha_prestamo, fecha_devolucion, estado) VALUES (1001, 1, 101, TO_DATE('2026-03-01', 'YYYY-MM-DD'), NULL, 'ACTIVO');
-- Préstamo ya devuelto
INSERT INTO PRESTAMO (id_prestamo, id_usuario, id_libro, fecha_prestamo, fecha_devolucion, estado) VALUES (1002, 2, 103, TO_DATE('2026-02-10', 'YYYY-MM-DD'), TO_DATE('2026-02-24', 'YYYY-MM-DD'), 'DEVUELTO');
-- Préstamo activo de otro usuario
INSERT INTO PRESTAMO (id_prestamo, id_usuario, id_libro, fecha_prestamo, fecha_devolucion, estado) VALUES (1003, 3, 105, TO_DATE('2026-03-05', 'YYYY-MM-DD'), NULL, 'ACTIVO');
-- Préstamo vencido (estado activo pero con fecha pasada)
INSERT INTO PRESTAMO (id_prestamo, id_usuario, id_libro, fecha_prestamo, fecha_devolucion, estado) VALUES (1004, 4, 102, TO_DATE('2026-01-10', 'YYYY-MM-DD'), NULL, 'VENCIDO');

