/*
Este script elimina todas las tablas del modelo de blibliotca.
*/

DROP FUNCTION contar_prestamos_activos;

DROP PROCEDURE registrar_usuario;
DROP PROCEDURE registrar_libro;
DROP PROCEDURE registrar_prestamo;
DROP PROCEDURE registrar_devolucion;
DROP PROCEDURE reporte_prestamos_vencidos;

DROP TABLE PRESTAMO;
DROP TABLE USUARIO;
DROP TABLE LIBRO;
DROP TABLE AUTOR;


