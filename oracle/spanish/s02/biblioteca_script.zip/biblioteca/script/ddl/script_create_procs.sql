
-- Procedimiento para registrar un nuevo usuario
CREATE OR REPLACE PROCEDURE registrar_usuario(
    p_id_usuario IN NUMBER,
    p_nombre IN VARCHAR2,
    p_email IN VARCHAR2,
    p_telefono IN VARCHAR2
) AS
BEGIN
    INSERT INTO USUARIO (id_usuario, nombre, email, telefono, fecha_registro)
    VALUES (p_id_usuario, p_nombre, p_email, p_telefono, SYSDATE);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Usuario registrado exitosamente');
EXCEPTION
    WHEN DUP_VAL_ON_INDEX THEN
        DBMS_OUTPUT.PUT_LINE('Error: El usuario ya existe');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END registrar_usuario;
/

-- Procedimiento para registrar un nuevo libro
CREATE OR REPLACE PROCEDURE registrar_libro(
    p_id_libro IN NUMBER,
    p_titulo IN VARCHAR2,
    p_id_autor IN NUMBER,
    p_isbn IN VARCHAR2,
    p_año IN NUMBER,
    p_cantidad IN NUMBER
) AS
BEGIN
    INSERT INTO LIBRO (id_libro, titulo, id_autor, isbn, año_publicacion, cantidad_disponible)
    VALUES (p_id_libro, p_titulo, p_id_autor, p_isbn, p_año, p_cantidad);
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Libro registrado exitosamente');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END registrar_libro;
/

CREATE OR REPLACE PROCEDURE registrar_prestamo(
    p_id_prestamo IN NUMBER,
    p_id_usuario IN NUMBER,
    p_id_libro IN NUMBER
) AS
    v_cantidad NUMBER;
BEGIN
    -- Verificar disponibilidad del libro
    SELECT cantidad_disponible INTO v_cantidad
    FROM   LIBRO
    WHERE id_libro = p_id_libro;
    
    IF v_cantidad > 0 THEN
        INSERT INTO PRESTAMO (id_prestamo, id_usuario, id_libro, fecha_prestamo, estado)
        VALUES (p_id_prestamo, p_id_usuario, p_id_libro, SYSDATE, 'ACTIVO');
        
        UPDATE LIBRO SET cantidad_disponible = cantidad_disponible - 1
        WHERE id_libro = p_id_libro;
        
        COMMIT;
        DBMS_OUTPUT.PUT_LINE('Préstamo registrado exitosamente');
    ELSE
        DBMS_OUTPUT.PUT_LINE('Error: Libro no disponible');
    END IF;
EXCEPTION
    WHEN NO_DATA_FOUND THEN
        DBMS_OUTPUT.PUT_LINE('Error: Libro no encontrado');
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END registrar_prestamo;
/

-- Procedimiento para registrar devolución
CREATE OR REPLACE PROCEDURE registrar_devolucion(
    p_id_prestamo IN NUMBER
) AS
    v_id_libro NUMBER;
BEGIN
    UPDATE PRESTAMO SET estado = 'DEVUELTO', fecha_devolucion = SYSDATE
    WHERE id_prestamo = p_id_prestamo
    RETURNING id_libro INTO v_id_libro;
    
    UPDATE LIBRO SET cantidad_disponible = cantidad_disponible + 1
    WHERE id_libro = v_id_libro;
    
    COMMIT;
    DBMS_OUTPUT.PUT_LINE('Devolución registrada exitosamente');
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
        ROLLBACK;
END registrar_devolucion;
/

-- Función para obtener el total de préstamos activos de un usuario
CREATE OR REPLACE FUNCTION contar_prestamos_activos(
    p_id_usuario IN NUMBER
) RETURN NUMBER AS
    v_total NUMBER;
BEGIN
    SELECT COUNT(*) INTO v_total
    FROM   PRESTAMO
    WHERE  id_usuario = p_id_usuario AND estado = 'ACTIVO';
    
    RETURN v_total;
EXCEPTION
    WHEN OTHERS THEN
        RETURN 0;
END contar_prestamos_activos;
/

-- Procedimiento para generar reporte de préstamos vencidos
CREATE OR REPLACE PROCEDURE reporte_prestamos_vencidos AS
    CURSOR c_prestamos_vencidos IS
        SELECT p.id_prestamo, u.nombre, l.titulo, p.fecha_prestamo,
               TRUNC(SYSDATE - p.fecha_prestamo) AS dias_vencido
        FROM PRESTAMO p
        JOIN USUARIO  u ON p.id_usuario = u.id_usuario
        JOIN LIBRO    l ON p.id_libro = l.id_libro
        WHERE p.estado = 'ACTIVO' AND p.fecha_prestamo < SYSDATE - 30
        ORDER BY dias_vencido DESC;
BEGIN
    DBMS_OUTPUT.PUT_LINE('=== REPORTE DE PRÉSTAMOS VENCIDOS ===');
    DBMS_OUTPUT.PUT_LINE('Fecha: ' || TO_CHAR(SYSDATE, 'DD/MM/YYYY'));
    DBMS_OUTPUT.PUT_LINE('');
    
    FOR v_prestamo IN c_prestamos_vencidos LOOP
        DBMS_OUTPUT.PUT_LINE('ID Préstamo: ' || v_prestamo.id_prestamo);
        DBMS_OUTPUT.PUT_LINE('Usuario: ' || v_prestamo.nombre);
        DBMS_OUTPUT.PUT_LINE('Libro: ' || v_prestamo.titulo);
        DBMS_OUTPUT.PUT_LINE('Días vencido: ' || v_prestamo.dias_vencido);
        DBMS_OUTPUT.PUT_LINE('---');
    END LOOP;
EXCEPTION
    WHEN OTHERS THEN
        DBMS_OUTPUT.PUT_LINE('Error: ' || SQLERRM);
END reporte_prestamos_vencidos;
/