-- esto es un comentario de ejemplo (una sola linea)
/*
este tambien es un comentario de ejemplo (varias lineas)
*/

-- Tabla AUTORES
CREATE TABLE AUTOR (
    id_autor NUMBER PRIMARY KEY,
    nombre VARCHAR2(50) NOT NULL,
    apellido VARCHAR2(50) NOT NULL,
    fecha_nacimiento DATE
);

-- Tabla LIBROS
CREATE TABLE LIBRO (
    id_libro NUMBER, -- PRIMARY KEY 
    titulo VARCHAR2(100) NOT NULL,
    id_autor NUMBER NOT NULL,
    isbn VARCHAR2(13) UNIQUE,
    año_publicacion NUMBER(4),
    cantidad_disponible NUMBER DEFAULT 0,
    CONSTRAINT PK_LIBRO PRIMARY KEY (id_libro),
    CONSTRAINT fk_libro_autor FOREIGN KEY (id_autor) REFERENCES AUTOR(id_autor)
);
    

-- Tabla USUARIOS
CREATE TABLE USUARIO (
    id_usuario NUMBER PRIMARY KEY,
    nombre VARCHAR2(100) NOT NULL,
    email VARCHAR2(100) UNIQUE NOT NULL,
    telefono VARCHAR2(15),
    fecha_registro DATE DEFAULT SYSDATE
);

-- Tabla PRESTAMOS
CREATE TABLE PRESTAMO (
    id_prestamo NUMBER PRIMARY KEY,
    id_usuario NUMBER NOT NULL,
    id_libro NUMBER NOT NULL,
    fecha_prestamo DATE DEFAULT SYSDATE,
    fecha_devolucion DATE,
    estado VARCHAR2(20) DEFAULT 'ACTIVO',
    CONSTRAINT fk_prestamo_usuario FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario),
    CONSTRAINT fk_prestamo_libro FOREIGN KEY (id_libro) REFERENCES LIBRO(id_libro)
);

-- Índices para mejorar el rendimiento de búsquedas
CREATE INDEX idx_libro_autor ON LIBRO(id_autor);
CREATE INDEX idx_libro_isbn ON LIBRO(isbn);
CREATE INDEX idx_usuario_email ON USUARIO(email);
CREATE INDEX idx_prestamo_usuario ON PRESTAMO(id_usuario);
CREATE INDEX idx_prestamo_libro ON PRESTAMO(id_libro);
CREATE INDEX idx_prestamo_estado ON PRESTAMO(estado);
CREATE INDEX idx_prestamo_fecha ON PRESTAMO(fecha_prestamo);
